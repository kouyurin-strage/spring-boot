package com.example.fileuploadingform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FileUploadingFormApplicationTests {

	@Test
	void contextLoads() {
	}

}
