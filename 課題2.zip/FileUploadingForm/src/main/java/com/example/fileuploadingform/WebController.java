package com.example.fileuploadingform;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.fileuploadingform.storage.StorageService;

@Controller
public class WebController implements WebMvcConfigurer {

	private final StorageService storageService;

	@Autowired
	public WebController(StorageService storageService) {
		this.storageService = storageService;
	}

	@Override
	public void addViewControllers(ViewControllerRegistry registry) {
		registry.addViewController("/results").setViewName("results");
	}
	  @GetMapping("/form")
	  public String greetingForm(Model model) {
	    model.addAttribute("personForm", new PersonForm());
	    return "form";
	  }

	  @PostMapping("/form")
	  public String greetingSubmit(@Valid @ModelAttribute PersonForm personForm, BindingResult bindingResult, Model model, RedirectAttributes redirectAttributes) {
		  if (bindingResult.hasErrors()) {
				return "form";
			}
		  storageService.store(personForm.getFile());
			redirectAttributes.addFlashAttribute("message",
					"You successfully uploaded " + personForm.getFile().getOriginalFilename() + "!");

	    model.addAttribute("personForm", personForm);
	    return "redirect:/results";
	  }
}
