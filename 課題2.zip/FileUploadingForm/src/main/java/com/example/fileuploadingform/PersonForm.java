package com.example.fileuploadingform;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.web.multipart.MultipartFile;
public class PersonForm {

	@NotNull
	@Size(min=2)
	private String name;

	@NotNull
	@Min(18)
	private Integer age;

	private MultipartFile file;
	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}


	public MultipartFile getFile() {
		return file;
	}

	public void setFile(MultipartFile file) {
		this.file = file;
	}
	public String toString() {
		return "Person(Name: " + this.name + ", Age: " + this.age + ",File: " + this.file +")";
	}
}
